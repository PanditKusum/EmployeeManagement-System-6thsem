 <nav>
      <h1> JHSS Employee Management System</h1>
      <ul id="navli">
        <li><a class="homered" href="index.php">HOME</a></li>
        <li><a class="homeblack" href="contact.html">CONTACT</a></li>
        <li><a class="homeblack" href="elogin.html">LOG IN</a></li>
      </ul>
    </nav>
    <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="picture/emp2.jpg" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        
      </div>   
    </div>
    <div class="carousel-item">
      <img src="picture/emp1.png"  width="1100" height="500">
      <div class="carousel-caption">
       
        
      </div>   
    </div>
    <div class="carousel-item">
      <img src="picture/cc3.png" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3> Employee UNiformity</h3>
        
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>



<nav>
      <h1> JHSS Employee Management System</h1>
      <ul id="navli">
        <li><a class="homered" href="index.php">HOME</a></li>
        <li><a class="homeblack" href="contact.html">CONTACT</a></li>
        <li><a class="homeblack" href="elogin.html">LOG IN</a></li>
      </ul>
    </nav>
  /header>
<div class="divider"></div>
  <div id="divimg">
    
  </div>

  
  <img src= "employee_self_service_banner.png"style="float: left; margin-right: 100px; margin-top: 35px; margin-left: 70px">
  

  <div style="margin-top: 400px">
    
    <h1 style="font-family: 'Lobster', cursive; font-weight: 200; font-size: 50px;margin-top: 175px; text-align: center;">Welcome to Employee Management System.
    </h1>
  </div>
    











<header>
		<nav>
			<h1>JHSS Employee Management System</h1>
			<div class="bg-img">
  <div class="container">
    <div class="topnav">
      <a class="homered" href="index.html"> Home </a>
      <a Class ="homered" href="contact.html"> Contact </a>
      <a class " homered" href="alogin.html"> Log In </a>
     
    </div>
  </div>
</div>
</nav>